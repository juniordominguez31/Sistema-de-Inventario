package Clases;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Inventario {

    //agregar producto (create)
    public boolean agregarProducto(Producto p) {
        Connection con = ConexionBD.conectar();
        String sqlGeneral = "INSERT INTO Productos VALUES (?, ?, ?, ?, ?, ?, ?)";
        String sqlEspecifico = "";

        try {
            //verificar duplicidad
            if (buscarPorCodigo(p.getCodigo()) != null) {
                System.out.println("Codigo ya registrado");
                return false;
            }

            //insertar datos generales
            PreparedStatement psGeneral = con.prepareStatement(sqlGeneral);
            psGeneral.setString(1, p.getCodigo());
            psGeneral.setString(2, p.getNombre());
            psGeneral.setString(3, p.getMarca());
            psGeneral.setDouble(4, p.getPrecio());
            psGeneral.setInt(5, p.getStock());
            psGeneral.setString(6, p.getFechaVencimiento());

            //definir tipo y tabla especifica
            if (p instanceof ProductoAerosol) {
                psGeneral.setString(7, "Aerosol");
                sqlEspecifico = "INSERT INTO ProductoAerosol VALUES (?, ?)";
            } else if (p instanceof ProductoLiquido) {
                psGeneral.setString(7, "Liquido");
                sqlEspecifico = "INSERT INTO ProductoLiquido VALUES (?, ?)";
            } else if (p instanceof ProductoSolido) {
                psGeneral.setString(7, "Solido");
                sqlEspecifico = "INSERT INTO ProductoSolido VALUES (?, ?)";
            } else if (p instanceof UtensilioLimpieza) {
                psGeneral.setString(7, "Utensilio");
                sqlEspecifico = "INSERT INTO UtensilioLimpieza VALUES (?, ?)";
            }

            psGeneral.executeUpdate();

            //Insertar datos especificos
            PreparedStatement psEspecifico = con.prepareStatement(sqlEspecifico);
            psEspecifico.setString(1, p.getCodigo());
            if (p instanceof ProductoAerosol) {
                psEspecifico.setInt(2, ((ProductoAerosol) p).getContenidoMl());
            } else if (p instanceof ProductoLiquido) {
                psEspecifico.setInt(2, ((ProductoLiquido) p).getVolumenMl());
            } else if (p instanceof ProductoSolido) {
                psEspecifico.setDouble(2, ((ProductoSolido) p).getPesoGramos());
            } else if (p instanceof UtensilioLimpieza) {
                psEspecifico.setString(2, ((UtensilioLimpieza) p).getMaterial());
            }
            psEspecifico.executeUpdate();

            System.out.println("Producto guardado en BD");
            return true;

        } catch (SQLException e) {
            System.out.println("Error al agregar: " + e.getMessage());
            return false;
        } finally {
            ConexionBD.desconectar(con);
        }
    }

    //buscar por codigo (read)
    public Producto buscarPorCodigo(String codigo) {
        Connection con = ConexionBD.conectar();
        Producto producto = null;
        String sql = "SELECT * FROM Productos WHERE codigo = ?";

        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, codigo);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                String tipo = rs.getString("tipo_producto");
                String nombre = rs.getString("nombre");
                String marca = rs.getString("marca");
                double precio = rs.getDouble("precio");
                int stock = rs.getInt("stock");
                String fecha = rs.getString("fecha_vencimiento");

                //Cargar datos especificos
                switch (tipo) {
                    case "Aerosol":
                        String sqlA = "SELECT contenido_ml FROM ProductoAerosol WHERE codigo = ?";
                        PreparedStatement psA = con.prepareStatement(sqlA);
                        psA.setString(1, codigo);
                        ResultSet rsA = psA.executeQuery();
                        if (rsA.next()) {
                            producto = new ProductoAerosol(codigo, nombre, marca, precio, stock, fecha, rsA.getInt("contenido_ml"));
                        }
                        break;
                    case "Liquido":
                        String sqlL = "SELECT volumen_ml FROM ProductoLiquido WHERE codigo = ?";
                        PreparedStatement psL = con.prepareStatement(sqlL);
                        psL.setString(1, codigo);
                        ResultSet rsL = psL.executeQuery();
                        if (rsL.next()) {
                            producto = new ProductoLiquido(codigo, nombre, marca, precio, stock, fecha, rsL.getInt("volumen_ml"));
                        }
                        break;
                    case "Solido":
                        String sqlS = "SELECT peso_gramos FROM ProductoSolido WHERE codigo = ?";
                        PreparedStatement psS = con.prepareStatement(sqlS);
                        psS.setString(1, codigo);
                        ResultSet rsS = psS.executeQuery();
                        if (rsS.next()) {
                            producto = new ProductoSolido(codigo, nombre, marca, precio, stock, fecha, rsS.getDouble("peso_gramos"));
                        }
                        break;
                    case "Utensilio":
                        String sqlU = "SELECT material FROM UtensilioLimpieza WHERE codigo = ?";
                        PreparedStatement psU = con.prepareStatement(sqlU);
                        psU.setString(1, codigo);
                        ResultSet rsU = psU.executeQuery();
                        if (rsU.next()) {
                            producto = new UtensilioLimpieza(codigo, nombre, marca, precio, stock, rsU.getString("material"));
                        }
                        break;
                }
            }
        } catch (SQLException e) {
            System.out.println("Error al buscar: " + e.getMessage());
        } finally {
            ConexionBD.desconectar(con);
        }
        return producto;
    }

    //buscar por nombre (con stream)
    public List<Producto> buscarPorNombre(String nombre) {
        List<Producto> todos = listarTodos();
        return todos.stream()
                .filter(p -> p.getNombre().equalsIgnoreCase(nombre))
                .collect(Collectors.toList());
    }

    //listar todos los productos
    public List<Producto> listarTodos() {
        List<Producto> lista = new ArrayList<>();
        Connection con = null;

        try {
        con = ConexionBD.conectar();
        if (con == null) {
            System.out.println("No se pudo conectar a la base de datos para listar");
            return lista;
        }

        //Consulta de los datos
        String sql = "SELECT p.*, a.contenido_ml, l.volumen_ml, s.peso_gramos, u.material " +
                     "FROM Productos p " +
                     "LEFT JOIN ProductoAerosol a ON p.codigo = a.codigo " +
                     "LEFT JOIN ProductoLiquido l ON p.codigo = l.codigo " +
                     "LEFT JOIN ProductoSolido s ON p.codigo = s.codigo " +
                     "LEFT JOIN UtensilioLimpieza u ON p.codigo = u.codigo";

        Statement st = con.createStatement();
        ResultSet rs = st.executeQuery(sql);

        while (rs.next()) {
            String codigo = rs.getString("codigo");
            String tipo = rs.getString("tipo_producto");
            String nombre = rs.getString("nombre");
            String marca = rs.getString("marca");
            double precio = rs.getDouble("precio");
            int stock = rs.getInt("stock");
            String fecha = rs.getString("fecha_vencimiento");

            Producto producto = null;
            switch (tipo) {
                case "Aerosol":
                    producto = new ProductoAerosol(codigo, nombre, marca, precio, stock, fecha, rs.getInt("contenido_ml"));
                    break;
                case "Liquido":
                    producto = new ProductoLiquido(codigo, nombre, marca, precio, stock, fecha, rs.getInt("volumen_ml"));
                    break;
                case "Solido":
                    producto = new ProductoSolido(codigo, nombre, marca, precio, stock, fecha, rs.getDouble("peso_gramos"));
                    break;
                case "Utensilio":
                    producto = new UtensilioLimpieza(codigo, nombre, marca, precio, stock, rs.getString("material"));
                    break;
            }
            if (producto != null) lista.add(producto);
        }

        System.out.println("Se encontraron " + lista.size() + " productos.");

    } catch (SQLException e) {
        System.out.println("Error al listar: " + e.getMessage());
    } finally {
        ConexionBD.desconectar(con);
    }
    return lista;
}

    public void listarInventario() {
        List<Producto> lista = listarTodos();
        if (lista.isEmpty()) {
            System.out.println("Inventario vacio");
            return;
        }
        //para expresion lambda
        lista.forEach(p -> p.mostrarDatos());
    }

    //modificar producto (update)
    public boolean modificarProducto(String codigo, Producto nuevo) {
        Connection con = ConexionBD.conectar();
        String sql = "UPDATE Productos SET nombre=?, marca=?, precio=?, stock=?, fecha_vencimiento=? WHERE codigo=?";

        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, nuevo.getNombre());
            ps.setString(2, nuevo.getMarca());
            ps.setDouble(3, nuevo.getPrecio());
            ps.setInt(4, nuevo.getStock());
            ps.setString(5, nuevo.getFechaVencimiento());
            ps.setString(6, codigo);
            int filas = ps.executeUpdate();

            //actualizar tabla especiifca
            if (filas > 0) {
                if (nuevo instanceof ProductoAerosol) {
                    String sqlE = "UPDATE ProductoAerosol SET contenido_ml=? WHERE codigo=?";
                    PreparedStatement psE = con.prepareStatement(sqlE);
                    psE.setInt(1, ((ProductoAerosol) nuevo).getContenidoMl());
                    psE.setString(2, codigo);
                    psE.executeUpdate();
                } else if (nuevo instanceof ProductoLiquido) {
                    String sqlE = "UPDATE ProductoLiquido SET volumen_ml=? WHERE codigo=?";
                    PreparedStatement psE = con.prepareStatement(sqlE);
                    psE.setInt(1, ((ProductoLiquido) nuevo).getVolumenMl());
                    psE.setString(2, codigo);
                    psE.executeUpdate();
                } else if (nuevo instanceof ProductoSolido) {
                    String sqlE = "UPDATE ProductoSolido SET peso_gramos=? WHERE codigo=?";
                    PreparedStatement psE = con.prepareStatement(sqlE);
                    psE.setDouble(1, ((ProductoSolido) nuevo).getPesoGramos());
                    psE.setString(2, codigo);
                    psE.executeUpdate();
                } else if (nuevo instanceof UtensilioLimpieza) {
                    String sqlE = "UPDATE UtensilioLimpieza SET material=? WHERE codigo=?";
                    PreparedStatement psE = con.prepareStatement(sqlE);
                    psE.setString(1, ((UtensilioLimpieza) nuevo).getMaterial());
                    psE.setString(2, codigo);
                    psE.executeUpdate();
                }
                System.out.println("Producto actualizado");
                return true;
            }
            return false;
        } catch (SQLException e) {
            System.out.println("Error al modificar: " + e.getMessage());
            return false;
        } finally {
            ConexionBD.desconectar(con);
        }
    }

    //eliminar producto (delete)
    public boolean eliminarProducto(String codigo) {
        Connection con = ConexionBD.conectar();
        String sql = "DELETE FROM Productos WHERE codigo = ?";

        try {
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, codigo);
            int filas = ps.executeUpdate();
            if (filas > 0) {
                System.out.println("Producto eliminado");
                return true;
            }
            return false;
        } catch (SQLException e) {
            System.out.println("Error al eliminar: " + e.getMessage());
            return false;
        } finally {
            ConexionBD.desconectar(con);
        }
    }

    //metodos vacios por compatibilidad
    public void guardarDatos() {}
    public void cargarDatos() {}
}