package Clases;

import Interfaz.IProducto;
import java.util.List;
import java.util.Scanner;

public class SistemaPrincipal {
    public static void main(String[] args) {
        Inventario inventario = new Inventario();
        Scanner entrada = new Scanner(System.in);
        int opcion;

        do {
            System.out.println("===== Inventario =====");
            System.out.println("===== CRUD de productos de limpieza =====");
            System.out.println("1. Listar");
            System.out.println("2. Insertar");
            System.out.println("3. Actualizar");
            System.out.println("4. Eliminar");
            System.out.println("0. Salir");
            System.out.print("Elija una opcion: ");
            
            while (!entrada.hasNextInt()) {
                System.out.print("Opcion invalida. Ingrese un numero: ");
                entrada.next();
            }
            opcion = entrada.nextInt();
            entrada.nextLine();

            switch (opcion) {
                //listar = Opcion 1
                case 1 -> inventario.listarInventario();

                //insertar = Opcion 2
                case 2 -> {
                    System.out.println("=== TIPO DE PRODUCTO ===");
                    System.out.println("1. Aerosol");
                    System.out.println("2. Liquido");
                    System.out.println("3. Solido");
                    System.out.println("4. Utensilio de limpieza");
                    System.out.print("Ingrese una opción: ");
                    
                    while (!entrada.hasNextInt()) {
                        System.out.print("Error. Ingrese solo un número (1-4): ");
                        entrada.next();
                    }
                    int tipo = entrada.nextInt();
                    entrada.nextLine();

                    if (tipo < 1 || tipo > 4) {
                        System.out.println("Tipo no valido. Operación cancelada");
                        break;
                    }

                    System.out.print("Codigo: ");
                    String cod = entrada.nextLine();

                    System.out.print("Nombre: ");
                    String nom = entrada.nextLine();
                    
                    System.out.print("Marca: ");
                    String mar = entrada.nextLine();

                    System.out.print("Precio: ");
                    while (!entrada.hasNextDouble()) {
                        System.out.print("Precio invalido. Ingrese un valor numerico: ");
                        entrada.next();
                    }
                    double pre = entrada.nextDouble();

                    System.out.print("Stock: ");
                    while (!entrada.hasNextInt()) {
                        System.out.print("Stock invalido. Ingrese un numero entero: ");
                        entrada.next();
                    }
                    int stk = entrada.nextInt();
                    entrada.nextLine();

                    String fec = "";
                    if (tipo != 4) {
                        System.out.print("Fecha Vencimiento: ");
                        fec = entrada.nextLine();
                    }

                    Producto nuevo = null;
                    try {
                        if (tipo == 1) {
                            System.out.print("Contenido (ml): ");
                            int ml = entrada.nextInt();
                            nuevo = new ProductoAerosol(cod, nom, mar, pre, stk, fec, ml);
                        } else if (tipo == 2) {
                            System.out.print("Volumen (ml): ");
                            int ml = entrada.nextInt();
                            nuevo = new ProductoLiquido(cod, nom, mar, pre, stk, fec, ml);
                        } else if (tipo == 3) {
                            System.out.print("Peso (gramos): ");
                            double gr = entrada.nextDouble();
                            nuevo = new ProductoSolido(cod, nom, mar, pre, stk, fec, gr);
                        } else if (tipo == 4) {
                            System.out.print("Material del utensilio: ");
                            String mat = entrada.nextLine();
                            nuevo = new UtensilioLimpieza(cod, nom, mar, pre, stk, mat);
                        }
                    } catch (Exception e) {
                        System.out.println("Error al ingresar datos: " + e.getMessage());
                    }

                    if (nuevo != null && inventario.agregarProducto(nuevo)) {
                        System.out.println("Producto insertado correctamente.");
                    } else {
                        System.out.println("Codigo ya existe o error al insertar.");
                    }
                }

                //actualizar = Opcion 3
                case 3 -> {
                    System.out.print("Codigo del producto a actualizar: ");
                    String cod = entrada.nextLine();

                    Producto encontrado = inventario.buscarPorCodigo(cod);
                    if (encontrado != null) {
                        System.out.print("Nuevo nombre (dejar vacio = no cambiar): ");
                        String nom = entrada.nextLine();
                        if (!nom.isBlank()) encontrado.setNombre(nom);

                        System.out.print("Nueva marca (dejar vacio = no cambiar): ");
                        String mar = entrada.nextLine();
                        if (!mar.isBlank()) encontrado.setMarca(mar);

                        System.out.print("Nuevo precio (dejar vacio = no cambiar): ");
                        String preStr = entrada.nextLine();
                        if (!preStr.isBlank()) {
                            try {
                                double pre = Double.parseDouble(preStr);
                                encontrado.setPrecio(pre);
                            } catch (NumberFormatException ex) {
                                System.out.println("Precio invalido, no se modifico");
                            }
                        }

                        System.out.print("Nuevo stock (dejar vacio = no cambiar): ");
                        String stkStr = entrada.nextLine();
                        if (!stkStr.isBlank()) {
                            try {
                                int stk = Integer.parseInt(stkStr);
                                encontrado.setStock(stk);
                            } catch (NumberFormatException ex) {
                                System.out.println("Stock invalido, no se modifico");
                            }
                        }

                        if (!(encontrado instanceof UtensilioLimpieza)) {
                            System.out.print("Nueva fecha venc. (dejar vacio = no cambiar): ");
                            String fec = entrada.nextLine();
                            if (!fec.isBlank()) encontrado.setFechaVencimiento(fec);
                        } else {
                            System.out.println("Este producto no requiere fecha de vencimiento");
                            UtensilioLimpieza ut = (UtensilioLimpieza) encontrado;
                            System.out.print("Nuevo material (dejar vacio = no cambiar): ");
                            String mat = entrada.nextLine();
                            if (!mat.isBlank()) ut.setMaterial(mat);
                        }

                        System.out.println("Producto actualizado correctamente");
                    } else {
                        System.out.println("Producto no encontrado");
                    }
                }

                //eliminar = Opcion 4
                case 4 -> {
                    System.out.print("Codigo del producto a eliminar: ");
                    String cod = entrada.nextLine();
                    if (inventario.eliminarProducto(cod)) {
                        System.out.println("Producto eliminado correctamente");
                    } else {
                        System.out.println("No existe el producto");
                    }
                    break;
                }
                
                case 0 -> {
                    System.out.println("Saliendo del sistema...");
                    inventario.guardarDatos();//Guardar al cerrar
                }
           
                default ->{
                    System.out.println("Opcion invalida, intente nuevamente");
                }
            }
        } while (opcion != 0);

    }
}