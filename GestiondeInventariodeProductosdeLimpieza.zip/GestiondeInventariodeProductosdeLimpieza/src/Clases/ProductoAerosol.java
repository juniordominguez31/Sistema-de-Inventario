package Clases;

import Interfaz.IProducto;
import java.io.Serializable;

public class ProductoAerosol extends Producto {
    private int contenidoMl;

    public ProductoAerosol() {
        super();
    }

    public ProductoAerosol(String codigo, String nombre, String marca, double precio, int stock, String fechaVencimiento, int contenidoMl) {
        super(codigo, nombre, marca, precio, stock, fechaVencimiento);
        this.contenidoMl = contenidoMl;
    }

    public int getContenidoMl() {
        return contenidoMl;
    }

    public void setContenidoMl(int contenidoMl) {
        this.contenidoMl = contenidoMl;
    }

    @Override
    public void mostrarDatos() {
        System.out.println("=====PRODUCTO AEROSOL=====");
        System.out.println("Codigo: " + getCodigo());
        System.out.println("Nombre: " + getNombre());
        System.out.println("Marca: " + getMarca());
        System.out.println("Precio: S/." + getPrecio());
        System.out.println("Stock: " + getStock());
        System.out.println("Vence: " + getFechaVencimiento());
        System.out.println("Contenido: " + contenidoMl + " ml");
        System.out.println("Valor total: S/." + calcularValorTotal());
        System.out.println("-------------------------");
    }
}