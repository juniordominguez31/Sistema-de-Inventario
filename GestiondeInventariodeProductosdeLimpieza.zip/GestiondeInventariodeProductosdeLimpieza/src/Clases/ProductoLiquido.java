package Clases;

import Interfaz.IProducto;
import java.io.Serializable;

public class ProductoLiquido extends Producto {
    private int volumenMl;

    public ProductoLiquido() {
        super();
    }

    //Constructor 
    public ProductoLiquido(String codigo, String nombre, String marca, double precio, int stock, String fechaVencimiento, int volumenMl) {
        super(codigo, nombre, marca, precio, stock, fechaVencimiento);
        this.volumenMl = volumenMl;
    }

    public int getVolumenMl() {
        return volumenMl;
    }

    public void setVolumenMl(int volumenMl) {
        this.volumenMl = volumenMl;
    }

    @Override
    public void mostrarDatos() {
        System.out.println("=====PRODUCTO LIQUIDO=====");
        System.out.println("Codigo: " + getCodigo());
        System.out.println("Nombre: " + getNombre());
        System.out.println("Marca: " + getMarca());
        System.out.println("Precio: S/." + getPrecio());
        System.out.println("Stock: " + getStock());
        System.out.println("Vence: " + getFechaVencimiento());
        System.out.println("Volumen: " + volumenMl + " ml"); // MUESTRA EN ML
        System.out.println("Valor total: S/." + calcularValorTotal());
        System.out.println("-------------------------");
    }
}