package Clases;

import Interfaz.IProducto;
import java.io.Serializable; 

public class UtensilioLimpieza extends Producto {
    //atributos 
    private String material; //Plastico o madera

    //constructores
    public UtensilioLimpieza() {
        super();
    }

    public UtensilioLimpieza(String codigo, String nombre, String marca, double precio, int stock, String material) {
        super(codigo, nombre, marca, precio, stock, "No aplica");
        this.material = material;
    }

    //getters y setters
    public String getMaterial() {
        return material;
    }

    public void setMaterial(String material) {
        if (!material.isBlank()) {
            this.material = material;
        }
    }

    // Sobreescribir el met.abstracto
    @Override
    public void mostrarDatos() {
        System.out.println("=== UTENSILIO DE LIMPIEZA ===");
        System.out.println("Codigo: " + getCodigo());
        System.out.println("Nombre: " + getNombre());
        System.out.println("Marca: " + getMarca());
        System.out.println("Precio: S/." + getPrecio());
        System.out.println("Stock: " + getStock());
        System.out.println("Material: " + material);
        System.out.println("Valor total: S/." + calcularValorTotal());
        System.out.println("-------------------------");
    }
}