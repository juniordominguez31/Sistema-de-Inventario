package Clases;

import Interfaz.IProducto;
import java.io.Serializable;

public class ProductoSolido extends Producto {
    private double pesoGramos;

    public ProductoSolido() {
        super();
    }

    public ProductoSolido(String codigo, String nombre, String marca, double precio, int stock, String fechaVencimiento, double pesoGramos) {
        super(codigo, nombre, marca, precio, stock, fechaVencimiento);
        this.pesoGramos = pesoGramos;
    }

    public double getPesoGramos() {
        return pesoGramos;
    }

    public void setPesoGramos(double pesoGramos) {
        this.pesoGramos = pesoGramos;
    }

    @Override
    public void mostrarDatos() {
        System.out.println("=== PRODUCTO SOLIDO ===");
        System.out.println("Codigo: " + getCodigo());
        System.out.println("Nombre: " + getNombre());
        System.out.println("Marca: " + getMarca());
        System.out.println("Precio: S/." + getPrecio());
        System.out.println("Stock: " + getStock());
        System.out.println("Vence: " + getFechaVencimiento());
        System.out.println("Peso: " + pesoGramos + " g");
        System.out.println("Valor total: S/." + calcularValorTotal());
        System.out.println("-------------------------");
    }
}