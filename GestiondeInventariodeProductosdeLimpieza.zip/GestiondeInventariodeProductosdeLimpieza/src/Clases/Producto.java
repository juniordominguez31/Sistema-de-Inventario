package Clases;

import Interfaz.IProducto;
import java.io.Serializable;

public abstract class Producto implements IProducto{
    private String codigo;
    private String nombre;
    private String marca;
    private double precio;
    private int stock;
    private String fechaVencimiento;

    public Producto() {
    }

    public Producto(String codigo, String nombre, String marca, double precio, int stock, String fechaVencimiento) {
        this.codigo = codigo;
        this.nombre = nombre;
        this.marca = marca;
        this.precio = (precio > 0) ? precio : 0.0;
        this.stock = (stock >= 0) ? stock : 0;
        this.fechaVencimiento = fechaVencimiento;
    }
    
    //getters y setters
    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (!nombre.isBlank()) {
            this.nombre = nombre;
        }
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        if (!marca.isBlank()) {
            this.marca = marca;
        }
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        if (precio > 0) {
            this.precio = precio;
        }
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        if (stock >= 0) {
            this.stock = stock;
        }
    }

    public String getFechaVencimiento() {
        return fechaVencimiento;
    }

    public void setFechaVencimiento(String fechaVencimiento) {
        this.fechaVencimiento = fechaVencimiento;
    }

    public double calcularValorTotal() {
        return precio * stock;
    }

    public abstract void mostrarDatos();
}