package Interfaz;

public interface IProducto {
    void mostrarDatos();
}